package domain;

import java.math.BigDecimal;

public class standard {
	private String bulidingid;
	private float waterbase;
	private BigDecimal waterprice;
	private float elebase;
	private BigDecimal eleprice;
	private String livingfee;
	private String note;
	public standard(String bulidingid, float waterbase, BigDecimal waterprice, float elebase, BigDecimal eleprice,
			String livingfee, String note) {
		super();
		this.bulidingid = bulidingid;
		this.waterbase = waterbase;
		this.waterprice = waterprice;
		this.elebase = elebase;
		this.eleprice = eleprice;
		this.livingfee = livingfee;
		this.note = note;
	}
	public standard() {
		super();
	}
	public String getBulidingid() {
		return bulidingid;
	}
	public void setBulidingid(String bulidingid) {
		this.bulidingid = bulidingid;
	}
	public float getWaterbase() {
		return waterbase;
	}
	public void setWaterbase(float waterbase) {
		this.waterbase = waterbase;
	}
	public BigDecimal getWaterprice() {
		return waterprice;
	}
	public void setWaterprice(BigDecimal waterprice) {
		this.waterprice = waterprice;
	}
	public float getElebase() {
		return elebase;
	}
	public void setElebase(float elebase) {
		this.elebase = elebase;
	}
	public BigDecimal getEleprice() {
		return eleprice;
	}
	public void setEleprice(BigDecimal eleprice) {
		this.eleprice = eleprice;
	}
	public String getLivingfee() {
		return livingfee;
	}
	public void setLivingfee(String livingfee) {
		this.livingfee = livingfee;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
	
}
