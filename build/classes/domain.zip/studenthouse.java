package domain;

import java.util.Date;

public class studenthouse {
private String stuid;
private String houseid;
private String buidingid;
private Date date;
public String getStuid() {
	return stuid;
}
public void setStuid(String stuid) {
	this.stuid = stuid;
}
public String getHouseid() {
	return houseid;
}
public void setHouseid(String houseid) {
	this.houseid = houseid;
}
public String getBuidingid() {
	return buidingid;
}
public void setBuidingid(String buidingid) {
	this.buidingid = buidingid;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public studenthouse(String stuid, String houseid, String buidingid, Date date) {
	super();
	this.stuid = stuid;
	this.houseid = houseid;
	this.buidingid = buidingid;
	this.date = date;
}
public studenthouse() {
	super();
	// TODO Auto-generated constructor stub
}

}
