package domain;

public class housething {
	private String bulidingid;
	private  String roomid;
	private int door_num;
	private String door_stat;
	private int desk_num;
	private String desk_stat;
	private int chair_num;
	private String chair_stat;
	private int light_num;
	private String light_stat;
	private int fan_num;
	private String fan_stat;
	private String others;
	public housething(String bulidingid, String roomid, int door_num, String door_stat, int desk_num, String desk_stat,
			int chair_num, String chair_stat, int light_num, String light_stat, int fan_num, String fan_stat,
			String others) {
		super();
		this.bulidingid = bulidingid;
		this.roomid = roomid;
		this.door_num = door_num;
		this.door_stat = door_stat;
		this.desk_num = desk_num;
		this.desk_stat = desk_stat;
		this.chair_num = chair_num;
		this.chair_stat = chair_stat;
		this.light_num = light_num;
		this.light_stat = light_stat;
		this.fan_num = fan_num;
		this.fan_stat = fan_stat;
		this.others = others;
	}
	public housething() {
		super();
	}
	public String getBulidingid() {
		return bulidingid;
	}
	public void setBulidingid(String bulidingid) {
		this.bulidingid = bulidingid;
	}
	public String getRoomid() {
		return roomid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public int getDoor_num() {
		return door_num;
	}
	public void setDoor_num(int door_num) {
		this.door_num = door_num;
	}
	public String getDoor_stat() {
		return door_stat;
	}
	public void setDoor_stat(String door_stat) {
		this.door_stat = door_stat;
	}
	public int getDesk_num() {
		return desk_num;
	}
	public void setDesk_num(int desk_num) {
		this.desk_num = desk_num;
	}
	public String getDesk_stat() {
		return desk_stat;
	}
	public void setDesk_stat(String desk_stat) {
		this.desk_stat = desk_stat;
	}
	public int getChair_num() {
		return chair_num;
	}
	public void setChair_num(int chair_num) {
		this.chair_num = chair_num;
	}
	public String getChair_stat() {
		return chair_stat;
	}
	public void setChair_stat(String chair_stat) {
		this.chair_stat = chair_stat;
	}
	public int getLight_num() {
		return light_num;
	}
	public void setLight_num(int light_num) {
		this.light_num = light_num;
	}
	public String getLight_stat() {
		return light_stat;
	}
	public void setLight_stat(String light_stat) {
		this.light_stat = light_stat;
	}
	public int getFan_num() {
		return fan_num;
	}
	public void setFan_num(int fan_num) {
		this.fan_num = fan_num;
	}
	public String getFan_stat() {
		return fan_stat;
	}
	public void setFan_stat(String fan_stat) {
		this.fan_stat = fan_stat;
	}
	public String getOthers() {
		return others;
	}
	public void setOthers(String others) {
		this.others = others;
	}
	
}
